import React, { Component } from 'react';

class BannerForum extends Component {
    render() {
        return (
            <div>
                <section className="banner">
                    <div className="container">
                        <h1 className="banner-title">
                            <a href="#" className="banner-title-link">Fórum </a>
                        </h1>
                    </div>
                </section>
            </div>
        );
    }
} export default BannerForum;